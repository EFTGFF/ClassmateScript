import random
import tkinter as tk
from tkinter import ttk
import subprocess
from PIL import Image, ImageTk

root = tk.Tk()
root.geometry("500x400")
root.title("DiscoverScript")
root.resizable(False, False)
root.configure(background="aqua")
root.wm_iconbitmap('pic/icon.ico')

def adss():
    seconds = random.randint(10, 30)
    seconds = seconds * 1000
    root.after(seconds, show_ad)

def show_ad():
    win = tk.Toplevel(root)
    win.geometry("500x400")
    win.title("AD")
    image_file = 'pic/AD.png'
    image = tk.PhotoImage(file=image_file)
    background_label = tk.Label(win, image=image)
    background_label.image = image
    background_label.pack()
    win.protocol("WM_DELETE_WINDOW", lambda: [win.destroy(), adss()])

def b1():
    program_path = 'ds/dsmain.exe'
    process = subprocess.run(['start',program_path],shell=True)

styles = ttk.Style()
styles.configure("Accent.TButton", foreground="black", background="aqua", font=("Segoe UI", 12))

buto = ttk.Button(
    root,
    text="运行DiscoverScript",
    command=b1,
    style="Accent.TButton"
    )
buto.place(x=170, y=50, width=160, height=40)

tes = tk.Label(
    root,
    text="油炸冥博士的DiscoverScript",
    font=("Segoe UI", 18),
    background="aqua"
    )
tes.place(x=100, y=5)

tess = tk.Label(
    root,
    text="DiscoverScript,油炸冥成名之作,全球8000亿用户的选择",
    font=("Segoe UI", 14, "bold"),
    background="aqua"
    )
tess.place(x=6, y=370)

image = ImageTk.PhotoImage(Image.open('pic/icon.ico'))
image_label = tk.Label(root, image=image, background="aqua")
image_label.image = image
image_label.place(x=215, y=90)

root.after(0, adss)
root.mainloop()